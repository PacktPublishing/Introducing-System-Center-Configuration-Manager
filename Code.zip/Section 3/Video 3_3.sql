﻿-- Wanted the top movie (rental amount) by genre?

-- WITH top_nc_17 AS (
-- SELECT f.film_id, f.title, f.rating, SUM(p.amount)
-- FROM film f 
--  JOIN inventory i ON f.film_id = i.film_id
--  JOIN rental r ON r.inventory_id = i.inventory_id
--  JOIN payment p ON p.rental_id = r.rental_id
-- 
-- WHERE f.rating = 'NC-17'
-- GROUP BY 1,2,3
-- ORDER BY SUM(p.amount) DESC
-- LIMIT 1
-- ),
-- 
-- top_r AS (
-- SELECT f.film_id, f.title, f.rating, SUM(p.amount)
-- FROM film f 
--  JOIN inventory i ON f.film_id = i.film_id
--  JOIN rental r ON r.inventory_id = i.inventory_id
--  JOIN payment p ON p.rental_id = r.rental_id
-- 
-- WHERE f.rating = 'R'
-- GROUP BY 1,2,3
-- ORDER BY SUM(p.amount) DESC
-- LIMIT 1
-- ),
-- 
-- top_g AS (
-- SELECT f.film_id, f.title, f.rating, SUM(p.amount)
-- FROM film f 
--  JOIN inventory i ON f.film_id = i.film_id
--  JOIN rental r ON r.inventory_id = i.inventory_id
--  JOIN payment p ON p.rental_id = r.rental_id
-- 
-- WHERE f.rating = 'G'
-- GROUP BY 1,2,3
-- ORDER BY SUM(p.amount) DESC
-- LIMIT 1
-- ),
-- 
-- top_pg AS (
-- SELECT f.film_id, f.title, f.rating, SUM(p.amount)
-- FROM film f 
--  JOIN inventory i ON f.film_id = i.film_id
--  JOIN rental r ON r.inventory_id = i.inventory_id
--  JOIN payment p ON p.rental_id = r.rental_id
-- 
-- WHERE f.rating = 'PG'
-- GROUP BY 1,2,3
-- ORDER BY SUM(p.amount) DESC
-- LIMIT 1
-- )
-- 
-- SELECT * FROM top_nc_17
-- UNION
-- SELECT * FROM top_r
-- UNION
-- SELECT * FROM top_g
-- UNION
-- SELECT * FROM top_pg

-- Window Functions

with base_table AS(
SELECT f.film_id, f.title, f.rating, SUM(p.amount)
FROM film f 
 JOIN inventory i ON f.film_id = i.film_id
 JOIN rental r ON r.inventory_id = i.inventory_id
 JOIN payment p ON p.rental_id = r.rental_id

GROUP BY 1,2,3
ORDER BY SUM(p.amount) DESC
), ranked_movies AS (

SELECT bt.*, row_number() OVER(partition by bt.rating ORDER BY bt.sum DESC) as rank_movie
FROM base_table bt
)

SELECT * FROM ranked_movies WHERE rank_movie = 1