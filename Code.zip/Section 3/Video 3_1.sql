﻿-- WHY use a subquery when you can use a where clause? underlying structure of the condition
-- Find all videos whose replacement cost is less than the average
-- What about greater than average?
-- how could we group them then?
-- So why? because as more films come in , the underlying structure of the average changes
-- then you wanted to check if it contains a special feature
SELECT t.* FROM (
	SELECT f.film_id, f.replacement_cost, f.special_features, 'gte_avg' as rep_cost_bucket,
		ARRAY['Commentaries'] && f.special_features as has_commentary
	FROM film f 
	WHERE f.replacement_cost > ( SELECT avg(f2.replacement_cost) FROM film f2  ) 

	UNION

	SELECT f.film_id, f.replacement_cost, f.special_features, 'lte_avg' as rep_cost_bucket,
		ARRAY['Commentaries'] && f.special_features as has_commentary
	FROM film f 
	WHERE f.replacement_cost <= ( SELECT avg(f2.replacement_cost) FROM film f2  ) 
)t WHERE t.has_commentary = 't'


-- Find a customer's max order date and its attributes

SELECT p.* 
FROM payment p JOIN (

 SELECT p2.customer_id, max(p2.payment_id) as max_pmt_id
 FROM payment p2 GROUP BY 1

) t ON t.max_pmt_id = p.payment_id



-- Filtering on some range customer id 150 to 200



SELECT p.* 
FROM payment p JOIN (

 SELECT p2.customer_id, max(p2.payment_id) as max_pmt_id
 FROM payment p2 GROUP BY 1

) t ON t.max_pmt_id = p.payment_id

WHERE p.customer_id IN (SELECT id FROM generate_series(150,200,1) id)




