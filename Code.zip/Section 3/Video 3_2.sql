﻿-- Get a customers total rental amount, but also their total in the month of 
-- Their first order

WITH base_table AS (
	SELECT p.customer_id, SUM(p.amount) as LTV, 
	(
	 SELECT EXTRACT(MONTH FROM MIN(p2.payment_date)) FROM payment p2 
	 WHERE p2.customer_id = p.customer_id
	) as first_order

	FROM payment p 
	GROUP BY 1
)

SELECT bt.*, (
 SELECT SUM(p3.amount) FROM payment p3
 WHERE p3.customer_id = bt.customer_id
 AND EXTRACT(MONTH FROM p3.payment_date) = bt.first_order
) as rental_amt_month_1
FROM base_table bt