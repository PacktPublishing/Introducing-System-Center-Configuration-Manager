﻿
CREATE TABLE customer_source(
  customer_id integer,
  source text
)

WITH base_table AS (
	SELECT cs.*, p.*
	FROM customer_source cs 
	JOIN payment p ON p.customer_id = cs.customer_id
)

SELECT bt.source, count(*), sum(bt.amount)::money
FROM base_table bt
GROUP BY 1
ORDER BY 2 DESC