﻿-- want to get counts of people who's last name starts with a vowel (AEIOU)
-- case, substring

-- SUM(CASE WHEN x.thing = 'whatever' THEN 1 ELSE 0 END) as counts_of_whatever

SELECT t.my_case_outcome, count(*) FROM (
SELECT c.*, substring(c.last_name, '^[AEIOUaeiou]') as x,

CASE
 WHEN substring(c.last_name, '^[AEIOUaeiou]') IS NOT NULL THEN 'last_starts_vow'
 ELSE 'novowel' 
 END as my_case_outcome,
 
CASE
 WHEN substring(c.last_name, '^[AEIOUaeiou]') IS NOT NULL THEN  substring(c.last_name, '^[AEIOUaeiou]') 
 ELSE 'novowel' 
 END as the_letter_or_not
 
FROM customer c
)t

GROUP BY 1






























-- SELECT c.*, 
-- 
-- CASE WHEN substring(c.last_name, '^[AEIOU]') IS NOT NULL THEN 'VOWEL' 
-- ELSE 'NOT VOWEL' 
-- END AS last_name_vowel_or_not
-- 
-- FROM customer c
