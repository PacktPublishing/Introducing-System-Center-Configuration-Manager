﻿
-- EXTRACT

-- TO CHAR

-- current_date

-- age



