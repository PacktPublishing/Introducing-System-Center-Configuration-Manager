﻿-- WHERE vs HAVING - going out with a flourish
-- Return Customers whose first order was on the weekend and was worth over 5 and who've spend at least 100 total
-- Note: Sunday = 0, Saturday = 6
-- This is kind of like a question you might get in the real world, almost. 

SELECT t.* FROM (
	SELECT p.*, EXTRACT(dow FROM p.payment_date), 

	(
	  SELECT SUM(p3.amount) FROM payment p3
	  WHERE p3.customer_id = p.customer_id
	) as CLV

	FROM payment p

	WHERE p.payment_id  = (
	  SELECT MIN(p2.payment_id) 
	  FROM payment p2 
	  WHERE p2.customer_id = p.customer_id
	)

	AND EXTRACT(dow FROM p.payment_date) IN (0,6)
	AND p.amount > 5
	GROUP BY 1
)t WHERE t.clv > 100
