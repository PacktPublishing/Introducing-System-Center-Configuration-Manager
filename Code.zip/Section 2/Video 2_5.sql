﻿-- JOIN gotchas, sometimes, if using a LEFT JOIN and nulls matter, put the 
-- filter on the JOIN itself

-- SELECT zebra::date, 'zebra', p.*
-- FROM generate_series('2007-02-01', '2007-02-28', INTERVAL '1 day') as zebra
-- LEFT JOIN payment p ON p.payment_date::date = zebra::date AND p.staff_id = 2
-- ORDER BY 3 NULLS FIRST

-- Chaining multiple conditions where OR is involved
-- from rental_id > 1400 and payment hour is between 8am to Noon or 2pm to 3pm

WITH base_table AS (
	SELECT zebra::date, 'zebra', p.*
	FROM generate_series('2007-02-01', '2007-02-28', INTERVAL '1 day') as zebra
	LEFT JOIN payment p ON p.payment_date::date = zebra::date AND p.staff_id = 2
	ORDER BY 3 NULLS FIRST
)

SELECT * FROM base_table bt
WHERE bt.rental_id > 1400
     
	AND EXTRACT(YEAR FROM bt.payment_date) IN (2007)
ORDER BY 6


-- WHERE in a subquery, WHERE some condition, WHERE using Aggregate

