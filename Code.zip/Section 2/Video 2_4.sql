﻿-- EVERYTHING is a table: how many customers purchase from multiple stores?

-- SELECT * FROM (
-- 	SELECT t.customer_id, COUNT(*) FROM (
-- 
-- 		SELECT DISTINCT r.customer_id, s.store_id 
-- 		FROM rental r
-- 			LEFT JOIN staff s ON s.staff_id = r.staff_id
-- 		ORDER BY 1
-- 	)t
-- 
-- 	GROUP BY 1
-- )t2
-- WHERE t2.customer_id < 10


WITH base_table AS (
	SELECT DISTINCT r.customer_id, s.store_id 
	FROM rental r
	 LEFT JOIN staff s ON s.staff_id = r.staff_id
	ORDER BY 1
),

WITH another_table AS (
	SELECT DISTINCT r.customer_id, s.store_id 
	FROM rental r
	 LEFT JOIN staff s ON s.staff_id = r.staff_id
	ORDER BY 1
)


SELECT bt.customer_id, COUNT(*)
FROM base_table bt 
GROUP BY 1