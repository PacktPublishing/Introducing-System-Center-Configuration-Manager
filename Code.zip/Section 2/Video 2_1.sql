﻿-- viewing our columns from which we can select, "what is in a row?"

-- SELECT * FROM payment p

-- making some selections, LIMIT / ORDER, Concatenate
-- 
-- SELECT p.payment_id, p.customer_id, p.amount
-- FROM payment p
-- ORDER BY 2 DESC, 3 ASC

-- some very simple WHERE clauses

SELECT p.payment_id, p.customer_id, p.amount, p.payment_date
FROM payment p
WHERE  EXTRACT(month FROM p.payment_date) = 2 
	AND p.amount > 1 
	
ORDER BY 2 DESC, 3 ASC


-- applying operations to columns and the need to GROUP BY
-- COUNT, DATES (extract, to_char, ::date), SUM, MAX, MIN, ARRAY_AGG



