﻿-- Has all inventory ever been rented?
-- SELECT 
-- 	f.film_id, f.title, 
-- 	i.store_id, i.inventory_id,
-- 	COUNT(distinct r.rental_id) as rentals
-- 	
-- FROM film f
-- 	LEFT JOIN inventory i ON i.film_id = f.film_id
-- 	LEFT JOIN rental r ON r.inventory_id = i.inventory_id
-- 	
-- GROUP BY 1,2,3,4
-- ORDER BY 3 NULLS FIRST

-- Finding a customer's first rental and various attributes about it

SELECT r.customer_id, min(r.rental_id) as first_order_id, 

(
  SELECT r2.rental_date FROM rental r2 WHERE r2.rental_id = min(r.rental_id) 
)::date first_order_date

FROM rental r
GROUP BY 1
ORDER BY 1


